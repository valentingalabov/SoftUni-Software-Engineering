﻿using MortalEngines.Core;
using MortalEngines.Entities.Contracts;

namespace MortalEngines
{
    public class StartUp
    {
        public static void Main()
        {
           
             
            
        }
    }
}