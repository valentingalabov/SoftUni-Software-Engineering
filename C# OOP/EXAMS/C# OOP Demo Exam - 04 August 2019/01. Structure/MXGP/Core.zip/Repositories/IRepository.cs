﻿namespace MXGP.Repositories
{
    public interface IRepository
    {
    }
}