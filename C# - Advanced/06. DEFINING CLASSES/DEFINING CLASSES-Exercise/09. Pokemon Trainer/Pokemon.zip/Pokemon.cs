﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PokemonTrainer
{
    public class Pokemon
    {

        public string Name;
        public string Type;
        public int Health;

        public Pokemon(string name, string type, int health)
        {
            Name = name;
            Type = type;
            Health = health;
        }




    }
}
